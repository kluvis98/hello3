/**
 * Author: Isaiah Kluver
 *         isaiah.kluver@huskers.unl.edu
 * Date: 2020/08/18
 *
 * A simple hello world program in C
 *
 */
#include <stdlib.h>
#include <stdio.h>

int main(int argc, char **argv) {

  printf("Isaiah Kluver!\n");

  return 0;
}
